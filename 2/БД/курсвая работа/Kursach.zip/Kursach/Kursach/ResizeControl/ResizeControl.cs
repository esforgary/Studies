﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ResizeControl
{
    public class FormResizeControl
    {
        //Изменение размера элемента
        public static void ResizeControl(Control control, Rectangle originalControlRect, float originalFontSize, float widthRatio, float heightRatio)
        {
            float newWidth = originalControlRect.Location.X * widthRatio;
            float newHeight = originalControlRect.Location.Y * heightRatio;

            control.Location = new Point((int)newWidth, (int)newHeight);
            control.Width = (int)(originalControlRect.Width * widthRatio);
            control.Height = (int)(originalControlRect.Height * heightRatio);

            float fontRatio = Math.Min(widthRatio, heightRatio);

            float newFontSize = originalFontSize * fontRatio;
            try
            {
                Font newFont = new Font(control.Font.FontFamily, newFontSize);
                control.Font = newFont;
            }
            catch (ArgumentException) { }
        }
    }
}
