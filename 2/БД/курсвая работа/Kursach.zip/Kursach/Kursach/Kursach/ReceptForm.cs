﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using ResizeControl;
using DatabaseCore;

namespace Kursach
{
    public partial class ReceptForm : Form
    {
        private Rectangle originalFormRect;

        private Rectangle originalDiagnoseLabelRect;
        private Rectangle originalReceptLabelRect;
        private Rectangle originalReceptListBoxRect;

        private float originalDiagnoseLabelFontSize;
        private float originalReceptLabelFontSize;
        private float originalReceptListBoxFontSize;

        private List<Recept> recepts; //Рецепты
        private string disease; //Болезнь

        public ReceptForm(List<Recept> recepts, string disease) //Получение рецептов и названия болезни
        {
            InitializeComponent();
            this.recepts = recepts;
            this.disease = disease;
        }

        private void ReceptForm_Load(object sender, EventArgs e)
        {
            originalFormRect = new Rectangle(this.Location, this.Size);
            originalDiagnoseLabelRect = new Rectangle(DiagnoseLabel.Location, DiagnoseLabel.Size);
            originalReceptLabelRect = new Rectangle(ReceptLabel.Location, ReceptLabel.Size);
            originalReceptListBoxRect = new Rectangle(ReceptListBox.Location, ReceptListBox.Size);

            originalDiagnoseLabelFontSize = DiagnoseLabel.Font.Size;
            originalReceptLabelFontSize = ReceptLabel.Font.Size;
            originalReceptListBoxFontSize = ReceptListBox.Font.Size;

            DiagnoseLabel.Text += disease;
            foreach (Recept recept in recepts) //Заполнение списка рецептов
                ReceptListBox.Items.Add("Препарат \"" + recept.Name_Med +
                    "\" принимать " + recept.Dosage +
                    " дозы " + recept.Count_receptions +
                    " раз(а) в день на протяжении " + recept.Count_days +
                    " дней");
        }

        private void ReceptForm_Resize(object sender, EventArgs e)
        {
            ResizeChildrenControls();
        }

        private void ResizeChildrenControls() //Изменение размеров всех элементов формы при изменении размера формы
        {
            float widthRatio = (float)this.ClientRectangle.Width / (float)originalFormRect.Width;
            float heightRatio = (float)this.ClientRectangle.Height / (float)originalFormRect.Height;

            FormResizeControl.ResizeControl(DiagnoseLabel, originalDiagnoseLabelRect, originalDiagnoseLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(ReceptLabel, originalReceptLabelRect, originalReceptLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(ReceptListBox, originalReceptListBoxRect, originalReceptListBoxFontSize, widthRatio, heightRatio);
        }
    }
}
