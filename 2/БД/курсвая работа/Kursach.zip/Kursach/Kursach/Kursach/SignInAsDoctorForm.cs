﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ResizeControl;

namespace Kursach
{
    public partial class SignInAsDoctorForm : Form
    {
        private string doctorPassword = "1111"; //Пароль

        private Rectangle originalFormRect;

        private Rectangle originalSignUpAsDoctorLabelRect;
        private Rectangle originalDoctorPasswordLabelRect;
        private Rectangle originalDoctorPasswordTextBoxRect;
        private Rectangle originalSignInButtonRect;
        private Rectangle originalEmptyTextFieldLabelRect;

        private float originalSignUpAsDoctorLabelFontSize;
        private float originalDoctorPasswordLabelFontSize;
        private float originalDoctorPasswordTextBoxFontSize;
        private float originalSignInButtonFontSize;
        private float originalEmptyTextFieldLabelFontSize;

        public SignInAsDoctorForm()
        {
            InitializeComponent();
        }

        private void SignUpAsDoctorForm_Load(object sender, EventArgs e)
        {
            originalFormRect = new Rectangle(this.Location, this.Size);
            originalSignUpAsDoctorLabelRect = new Rectangle(SignUpAsDoctorLabel.Location, SignUpAsDoctorLabel.Size);
            originalDoctorPasswordLabelRect = new Rectangle(DoctorPasswordLabel.Location, DoctorPasswordLabel.Size);
            originalDoctorPasswordTextBoxRect = new Rectangle(DoctorPasswordTextBox.Location, DoctorPasswordTextBox.Size);
            originalSignInButtonRect = new Rectangle(SignInButton.Location, SignInButton.Size);
            originalEmptyTextFieldLabelRect = new Rectangle(EmptyTextFieldLabel.Location, EmptyTextFieldLabel.Size);

            originalSignUpAsDoctorLabelFontSize = SignUpAsDoctorLabel.Font.Size;
            originalDoctorPasswordLabelFontSize = DoctorPasswordLabel.Font.Size;
            originalDoctorPasswordTextBoxFontSize = DoctorPasswordTextBox.Font.Size;
            originalSignInButtonFontSize = SignInButton.Font.Size;
            originalEmptyTextFieldLabelFontSize = EmptyTextFieldLabel.Font.Size;
        }

        private void SignUpAsDoctorForm_Resize(object sender, EventArgs e)
        {
            ResizeChildrenControls();
        }

        private void ResizeChildrenControls() //Изменение размеров всех элементов формы при изменении размера формы
        {
            float widthRatio = (float)this.ClientRectangle.Width / (float)originalFormRect.Width;
            float heightRatio = (float)this.ClientRectangle.Height / (float)originalFormRect.Height;

            FormResizeControl.ResizeControl(SignUpAsDoctorLabel, originalSignUpAsDoctorLabelRect, originalSignUpAsDoctorLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(DoctorPasswordLabel, originalDoctorPasswordLabelRect, originalDoctorPasswordLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(DoctorPasswordTextBox, originalDoctorPasswordTextBoxRect, originalDoctorPasswordTextBoxFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(SignInButton, originalSignInButtonRect, originalSignInButtonFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(EmptyTextFieldLabel, originalEmptyTextFieldLabelRect, originalEmptyTextFieldLabelFontSize, widthRatio, heightRatio);
        }

        private void DoctorPasswordTextBox_TextChanged(object sender, EventArgs e)
        {
            EmptyTextFieldLabel.Visible = false;
        }

        private void SignInButton_Click(object sender, EventArgs e) //При нажатии на "Войти"
        {
            if (String.IsNullOrEmpty(DoctorPasswordTextBox.Text)) //Сообщает, если пароль пустой
            {
                EmptyTextFieldLabel.Text = "Это поле не может быть пустым";
                EmptyTextFieldLabel.Visible = true;
            }
            else if (DoctorPasswordTextBox.Text != doctorPassword) //Сообщает, если пароль неправильный
            {
                EmptyTextFieldLabel.Text = "Неправильный пароль";
                EmptyTextFieldLabel.Visible = true;
            }
            else
            {
                //Переход на форму "Доктор"
                this.Hide();
                var doctorForm = new DoctorForm();
                doctorForm.Closed += (s, args) => this.Close();
                doctorForm.Show();
            }
        }
    }
}
