﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using ResizeControl;
using DatabaseCore;

namespace Kursach
{
    public partial class AppointmentForm : Form
    {
        private Rectangle originalFormRect;

        private Rectangle originalFullNameLabelRect;
        private Rectangle originalFullNameTextBoxRect;
        private Rectangle originalPhoneNumberLabelRect;
        private Rectangle originalPhoneNumberTextBoxRect;
        private Rectangle originalComplaintLabelRect;
        private Rectangle originalComplaintTextBoxRect;
        private Rectangle originalMakeAnAppointmentButtonRect;
        private Rectangle originalAppoitmentLabelRect;
        private Rectangle originalEmptyTextFieldLabel1Rect;
        private Rectangle originalEmptyTextFieldLabel2Rect;
        private Rectangle originalEmptyTextFieldLabel3Rect;

        private float originalFullNameLabelFontSize;
        private float originalFullNameTextBoxFontSize;
        private float originalPhoneNumberLabelFontSize;
        private float originalPhoneNumberTextBoxFontSize;
        private float originalComplaintLabelFontSize;
        private float originalComplaintTextBoxFontSize;
        private float originalMakeAnAppointmentButtonFontSize;
        private float originalAppoitmentLabelFontSize;
        private float originalEmptyTextFieldLabel1FontSize;
        private float originalEmptyTextFieldLabel2FontSize;
        private float originalEmptyTextFieldLabel3FontSize;

        public AppointmentForm()
        {
            InitializeComponent();
        }

        private void AppointmentForm_Load(object sender, EventArgs e)
        {
            originalFormRect = new Rectangle(this.Location, this.Size);
            originalFullNameLabelRect = new Rectangle(FullNameLabel.Location, FullNameLabel.Size);
            originalFullNameTextBoxRect = new Rectangle(FullNameTextBox.Location, FullNameTextBox.Size);
            originalPhoneNumberLabelRect = new Rectangle(PhoneNumberLabel.Location, PhoneNumberLabel.Size);
            originalPhoneNumberTextBoxRect = new Rectangle(PhoneNumberTextBox.Location, PhoneNumberTextBox.Size);
            originalComplaintLabelRect = new Rectangle(ComplaintLabel.Location, ComplaintLabel.Size);
            originalComplaintTextBoxRect = new Rectangle(ComplaintTextBox.Location, ComplaintTextBox.Size);
            originalMakeAnAppointmentButtonRect = new Rectangle(MakeAnAppointmentButton.Location, MakeAnAppointmentButton.Size);
            originalAppoitmentLabelRect = new Rectangle(AppoitmentLabel.Location, AppoitmentLabel.Size);
            originalEmptyTextFieldLabel1Rect = new Rectangle(EmptyTextFieldLabel1.Location, EmptyTextFieldLabel1.Size);
            originalEmptyTextFieldLabel2Rect = new Rectangle(EmptyTextFieldLabel2.Location, EmptyTextFieldLabel2.Size);
            originalEmptyTextFieldLabel3Rect = new Rectangle(EmptyTextFieldLabel3.Location, EmptyTextFieldLabel3.Size);

            originalFullNameLabelFontSize = FullNameLabel.Font.Size;
            originalFullNameTextBoxFontSize = FullNameTextBox.Font.Size;
            originalPhoneNumberLabelFontSize = PhoneNumberLabel.Font.Size;
            originalPhoneNumberTextBoxFontSize = PhoneNumberTextBox.Font.Size;
            originalComplaintLabelFontSize = ComplaintLabel.Font.Size;
            originalComplaintTextBoxFontSize = ComplaintTextBox.Font.Size;
            originalMakeAnAppointmentButtonFontSize = MakeAnAppointmentButton.Font.Size;
            originalAppoitmentLabelFontSize = AppoitmentLabel.Font.Size;
            originalEmptyTextFieldLabel1FontSize = EmptyTextFieldLabel1.Font.Size;
            originalEmptyTextFieldLabel2FontSize = EmptyTextFieldLabel2.Font.Size;
            originalEmptyTextFieldLabel3FontSize = EmptyTextFieldLabel3.Font.Size;
        }

        private void AppointmentForm_Resize(object sender, EventArgs e)
        {
            ResizeChildrenControls();
        }

        private void ResizeChildrenControls() //Изменение размеров всех элементов формы при изменении размера формы
        {
            float widthRatio = (float)this.ClientRectangle.Width / (float)originalFormRect.Width;
            float heightRatio = (float)this.ClientRectangle.Height / (float)originalFormRect.Height;

            FormResizeControl.ResizeControl(FullNameLabel, originalFullNameLabelRect, originalFullNameLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(FullNameTextBox, originalFullNameTextBoxRect, originalFullNameTextBoxFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(PhoneNumberLabel, originalPhoneNumberLabelRect, originalPhoneNumberLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(PhoneNumberTextBox, originalPhoneNumberTextBoxRect, originalPhoneNumberTextBoxFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(ComplaintLabel, originalComplaintLabelRect, originalComplaintLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(ComplaintTextBox, originalComplaintTextBoxRect, originalComplaintTextBoxFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(MakeAnAppointmentButton, originalMakeAnAppointmentButtonRect, originalMakeAnAppointmentButtonFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(AppoitmentLabel, originalAppoitmentLabelRect, originalAppoitmentLabelFontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(EmptyTextFieldLabel1, originalEmptyTextFieldLabel1Rect, originalEmptyTextFieldLabel1FontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(EmptyTextFieldLabel2, originalEmptyTextFieldLabel2Rect, originalEmptyTextFieldLabel2FontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(EmptyTextFieldLabel3, originalEmptyTextFieldLabel3Rect, originalEmptyTextFieldLabel3FontSize, widthRatio, heightRatio);
        }

        private void SignInAsDoctorButton_MouseHover(object sender, EventArgs e) //Закрашивание красным кнопки при наведении
        {
            SignInAsDoctorButton.ImageIndex = 1;
            SignInAsDoctorButton.BackColor = Color.FromArgb(203, 239, 253);
        }

        //Возврат прозрачной кнопки
        private void SignInAsDoctorButton_MouseLeave(object sender, EventArgs e) => SignInAsDoctorButton.ImageIndex = 0;

        private bool IsFullNameCorrect() //Проверка правильности введения ФИО (правильный формат: "Фамилия И. О.")
        {
            if (String.IsNullOrEmpty(FullNameTextBox.Text))
            {
                EmptyTextFieldLabel1.Text = "Это поле не может быть пустым";
                EmptyTextFieldLabel1.Visible = true;
                return false;
            }
            else if (FullNameTextBox.Text.Split(' ').Length != 3
                || !Regex.IsMatch(FullNameTextBox.Text, @"^[а-яА-Я. ]+$")
                || FullNameTextBox.Text.Split(' ')[1].Length != 2
                || FullNameTextBox.Text.Split(' ')[2].Length != 2)
            {
                EmptyTextFieldLabel1.Text = "Введите вашу полную фамилию и инициалы через пробел";
                EmptyTextFieldLabel1.Visible = true;
                return false;
            }
            FullNameCorrection();
            return true;
        }

        private void FullNameTextBox_LostFocus(object sender, EventArgs e) => IsFullNameCorrect();

        private void FullNameTextBox_TextChanged(object sender, EventArgs e) => EmptyTextFieldLabel1.Visible = false;

        private bool IsPhoneNumberCorrect() //Проверка правильности введения номера телефона
        {
            if (PhoneNumberTextBox.Text.Length <= 4)
            {
                EmptyTextFieldLabel2.Visible = true;
                PhoneNumberTextBox.Text = "+380";
                return false;
            }
            else if (PhoneNumberTextBox.Text.Length != 13 || !long.TryParse(PhoneNumberTextBox.Text[1..], out long n))
            {
                EmptyTextFieldLabel2.Visible = true;
                return false;
            }
            return true;
        }

        private void PhoneNumberTextBox_LostFocus(object sender, EventArgs e) => IsPhoneNumberCorrect();

        private void PhoneNumberTextBox_TextChanged(object sender, EventArgs e)
        {
            if (PhoneNumberTextBox.Focused)
                EmptyTextFieldLabel2.Visible = false;
            if (PhoneNumberTextBox.Text.Length > 13)
            {
                PhoneNumberTextBox.Text = PhoneNumberTextBox.Text[..^1];
                PhoneNumberTextBox.SelectionStart = PhoneNumberTextBox.Text.Length;
                PhoneNumberTextBox.SelectionLength = 0;
            }
        }

        private void ComplaintTextBox_LostFocus(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(ComplaintTextBox.Text))
                EmptyTextFieldLabel3.Visible = true;
        }

        private void ComplaintTextBox_TextChanged(object sender, EventArgs e) => EmptyTextFieldLabel3.Visible = false;

        private void FullNameCorrection() //Исправление ФИО (делает первую букву фамилии и буквы инициалов большими)
        {
            string[] fullName = FullNameTextBox.Text.Split(' ');
            FullNameTextBox.Text = char.ToUpper(fullName[0][0]) + fullName[0].Substring(1) + ' ' + 
                char.ToUpper(fullName[1][0]) + fullName[1].Substring(1) + ' ' + 
                char.ToUpper(fullName[2][0]) + fullName[2].Substring(1);
        }

        private void MakeAnAppointmentButton_Click(object sender, EventArgs e) //Нажатие на кнопку "Записаться"
        {
            bool allFieldsFilled = true;
            if (!IsFullNameCorrect())
                allFieldsFilled = false;
            if (!IsPhoneNumberCorrect())
                allFieldsFilled = false;
            if (String.IsNullOrEmpty(ComplaintTextBox.Text))
            {
                EmptyTextFieldLabel3.Visible = true;
                allFieldsFilled = false;
            }
            if (allFieldsFilled) //Если все поля заполнены правильно
            {
                //В конструктор БД передаётся строка подключения
                Database database = new Database("Data Source=ESFORGARY;Initial Catalog=DoctorsHandbook;Integrated Security=SSPI;TrustServerCertificate=True");
                try
                {
                    int id_dis = database.Diagnose(ComplaintTextBox.Text);
                    if (id_dis == 0)
                        MessageBox.Show("Не могу найти болезнь с такими симптомами, попробуйте описать их подробнее");
                    else //Если болезнь определена
                    {
                        //Добавление нового пациента, осмотра и рецепта
                        database.InsertNewPatient(FullNameTextBox.Text, PhoneNumberTextBox.Text);
                        int id_ins = database.InsertNewInspection(id_dis, ComplaintTextBox.Text, FullNameTextBox.Text, PhoneNumberTextBox.Text);
                        database.InsertNewRecept(id_ins);
                        //Получение рецепта и болезни, переход на форму "Рецепт" с полученными данными
                        List<Recept> recept = database.GetRecept(id_ins);
                        string disease = database.GetDisease(id_ins);
                        this.Hide();
                        var receptForm = new ReceptForm(recept, disease);
                        receptForm.Closed += (s, args) => this.Close();
                        receptForm.Show();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void SignInAsDoctorButton_Click(object sender, EventArgs e) //При нажатии на "Войти как доктор"
        {
            //Переход на форму "Войти как доктор"
            this.Hide();
            var signInAsDoctorForm = new SignInAsDoctorForm();
            signInAsDoctorForm.Closed += (s, args) => this.Close();
            signInAsDoctorForm.Show();
        }
    }
}
