﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using ResizeControl;
using DatabaseCore;

namespace Kursach
{
    public partial class DoctorForm : Form
    {
        private Rectangle originalFormRect;

        private Rectangle originalChart1Rect;
        private Rectangle originalChart2Rect;
        private Rectangle originalChart3Rect;
        private Rectangle originalInspectionsDataGridViewRect;

        private float originalChart1FontSize;
        private float originalChart2FontSize;
        private float originalChart3FontSize;
        private float originalInspectionsDataGridViewFontSize;

        public DoctorForm()
        {
            InitializeComponent();
        }

        private void DoctorForm_Load(object sender, EventArgs e)
        {
            originalFormRect = new Rectangle(this.Location, this.Size);
            originalChart1Rect = new Rectangle(chart1.Location, chart1.Size);
            originalChart2Rect = new Rectangle(chart2.Location, chart2.Size);
            originalChart3Rect = new Rectangle(chart3.Location, chart3.Size);
            originalInspectionsDataGridViewRect = new Rectangle(InspectionsDataGridView.Location, InspectionsDataGridView.Size);

            originalChart1FontSize = chart1.Font.Size;
            originalChart2FontSize = chart2.Font.Size;
            originalChart3FontSize = chart3.Font.Size;
            originalInspectionsDataGridViewFontSize = InspectionsDataGridView.Font.Size;

            //В конструктор БД передаётся строка подключения
            Database database = new Database("Data Source=ESFORGARY;Initial Catalog=DoctorsHandbook;Integrated Security=SSPI;TrustServerCertificate=True");
            try
            {
                InspectionsDataGridView.DataSource = database.GetAllInspections(); //Заполнение таблицы
                Dictionary<string, int> data = database.GetCountedDiseases();
                DrawChart(chart1, data, "Заболеваемость"); //Диаграмма заболеваемости
                data = database.GetCountedPatients();
                DrawChart(chart2, data, "Посещаемость"); //Диаграмма посещаемости
                data = database.GetCountedMedication();
                DrawChart(chart3, data, "Медикаменты"); //Диаграмма медикаментов
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DrawChart(Chart chart, Dictionary<string, int> data, string name) //Создание диаграммы
        {
            int chartPieces = 5; //Количество частей на диаграмме
            int i = 0;
            chart.Titles.Add(name);
            foreach (string value in data.Keys)
            {
                if (i < chartPieces)
                    chart.Series["series"].Points.AddXY(value, data[value]);
                else
                    break;
                i++;
            }
        }

        private void DoctorForm_Resize(object sender, EventArgs e)
        {
            ResizeChildrenControls();
        }

        private void ResizeChildrenControls() //Изменение размеров всех элементов формы при изменении размера формы
        {
            float widthRatio = (float)this.ClientRectangle.Width / (float)originalFormRect.Width;
            float heightRatio = (float)this.ClientRectangle.Height / (float)originalFormRect.Height;

            FormResizeControl.ResizeControl(chart1, originalChart1Rect, originalChart1FontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(chart2, originalChart2Rect, originalChart2FontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(chart3, originalChart3Rect, originalChart3FontSize, widthRatio, heightRatio);
            FormResizeControl.ResizeControl(InspectionsDataGridView, originalInspectionsDataGridViewRect, originalInspectionsDataGridViewFontSize, widthRatio, heightRatio);
        }
    }
}