﻿
namespace Kursach
{
    partial class ReceptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReceptLabel = new System.Windows.Forms.Label();
            this.ReceptListBox = new System.Windows.Forms.ListBox();
            this.DiagnoseLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ReceptLabel
            // 
            this.ReceptLabel.AutoSize = true;
            this.ReceptLabel.Font = new System.Drawing.Font("Segoe UI", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ReceptLabel.Location = new System.Drawing.Point(49, 90);
            this.ReceptLabel.Name = "ReceptLabel";
            this.ReceptLabel.Size = new System.Drawing.Size(309, 62);
            this.ReceptLabel.TabIndex = 0;
            this.ReceptLabel.Text = "Ваш рецепт:";
            // 
            // ReceptListBox
            // 
            this.ReceptListBox.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ReceptListBox.FormattingEnabled = true;
            this.ReceptListBox.HorizontalScrollbar = true;
            this.ReceptListBox.ItemHeight = 31;
            this.ReceptListBox.Location = new System.Drawing.Point(49, 175);
            this.ReceptListBox.Name = "ReceptListBox";
            this.ReceptListBox.Size = new System.Drawing.Size(906, 314);
            this.ReceptListBox.TabIndex = 1;
            this.ReceptListBox.TabStop = false;
            this.ReceptListBox.UseTabStops = false;
            // 
            // DiagnoseLabel
            // 
            this.DiagnoseLabel.AutoSize = true;
            this.DiagnoseLabel.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DiagnoseLabel.Location = new System.Drawing.Point(49, 27);
            this.DiagnoseLabel.Name = "DiagnoseLabel";
            this.DiagnoseLabel.Size = new System.Drawing.Size(466, 54);
            this.DiagnoseLabel.TabIndex = 2;
            this.DiagnoseLabel.Text = "Вам поставлен диагноз: ";
            // 
            // ReceptForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(239)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(1005, 556);
            this.Controls.Add(this.DiagnoseLabel);
            this.Controls.Add(this.ReceptListBox);
            this.Controls.Add(this.ReceptLabel);
            this.Name = "ReceptForm";
            this.Text = "Рецепт";
            this.Load += new System.EventHandler(this.ReceptForm_Load);
            this.Resize += new System.EventHandler(this.ReceptForm_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ReceptLabel;
        private System.Windows.Forms.ListBox ReceptListBox;
        private System.Windows.Forms.Label DiagnoseLabel;
    }
}