﻿
namespace Kursach
{
    partial class AppointmentForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AppointmentForm));
            this.FullNameLabel = new System.Windows.Forms.Label();
            this.PhoneNumberLabel = new System.Windows.Forms.Label();
            this.ComplaintLabel = new System.Windows.Forms.Label();
            this.FullNameTextBox = new System.Windows.Forms.TextBox();
            this.PhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.ComplaintTextBox = new System.Windows.Forms.TextBox();
            this.MakeAnAppointmentButton = new System.Windows.Forms.Button();
            this.SignInAsDoctorButton = new System.Windows.Forms.Button();
            this.ImageListForButton = new System.Windows.Forms.ImageList(this.components);
            this.EmptyTextFieldLabel1 = new System.Windows.Forms.Label();
            this.EmptyTextFieldLabel2 = new System.Windows.Forms.Label();
            this.EmptyTextFieldLabel3 = new System.Windows.Forms.Label();
            this.AppoitmentLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // FullNameLabel
            // 
            this.FullNameLabel.AutoSize = true;
            this.FullNameLabel.Location = new System.Drawing.Point(43, 79);
            this.FullNameLabel.Name = "FullNameLabel";
            this.FullNameLabel.Size = new System.Drawing.Size(42, 20);
            this.FullNameLabel.TabIndex = 0;
            this.FullNameLabel.Text = "ФИО";
            // 
            // PhoneNumberLabel
            // 
            this.PhoneNumberLabel.AutoSize = true;
            this.PhoneNumberLabel.Location = new System.Drawing.Point(43, 149);
            this.PhoneNumberLabel.Name = "PhoneNumberLabel";
            this.PhoneNumberLabel.Size = new System.Drawing.Size(69, 20);
            this.PhoneNumberLabel.TabIndex = 1;
            this.PhoneNumberLabel.Text = "Телефон";
            // 
            // ComplaintLabel
            // 
            this.ComplaintLabel.AutoSize = true;
            this.ComplaintLabel.Location = new System.Drawing.Point(43, 227);
            this.ComplaintLabel.Name = "ComplaintLabel";
            this.ComplaintLabel.Size = new System.Drawing.Size(64, 20);
            this.ComplaintLabel.TabIndex = 2;
            this.ComplaintLabel.Text = "Жалоба";
            // 
            // FullNameTextBox
            // 
            this.FullNameTextBox.Location = new System.Drawing.Point(43, 102);
            this.FullNameTextBox.Name = "FullNameTextBox";
            this.FullNameTextBox.Size = new System.Drawing.Size(332, 27);
            this.FullNameTextBox.TabIndex = 3;
            this.FullNameTextBox.TabStop = false;
            this.FullNameTextBox.TextChanged += new System.EventHandler(this.FullNameTextBox_TextChanged);
            this.FullNameTextBox.Leave += new System.EventHandler(this.FullNameTextBox_LostFocus);
            // 
            // PhoneNumberTextBox
            // 
            this.PhoneNumberTextBox.Location = new System.Drawing.Point(43, 172);
            this.PhoneNumberTextBox.Name = "PhoneNumberTextBox";
            this.PhoneNumberTextBox.Size = new System.Drawing.Size(332, 27);
            this.PhoneNumberTextBox.TabIndex = 4;
            this.PhoneNumberTextBox.TabStop = false;
            this.PhoneNumberTextBox.Text = "+380";
            this.PhoneNumberTextBox.TextChanged += new System.EventHandler(this.PhoneNumberTextBox_TextChanged);
            this.PhoneNumberTextBox.Leave += new System.EventHandler(this.PhoneNumberTextBox_LostFocus);
            // 
            // ComplaintTextBox
            // 
            this.ComplaintTextBox.Location = new System.Drawing.Point(43, 250);
            this.ComplaintTextBox.Multiline = true;
            this.ComplaintTextBox.Name = "ComplaintTextBox";
            this.ComplaintTextBox.Size = new System.Drawing.Size(332, 81);
            this.ComplaintTextBox.TabIndex = 5;
            this.ComplaintTextBox.TabStop = false;
            this.ComplaintTextBox.TextChanged += new System.EventHandler(this.ComplaintTextBox_TextChanged);
            this.ComplaintTextBox.Leave += new System.EventHandler(this.ComplaintTextBox_LostFocus);
            // 
            // MakeAnAppointmentButton
            // 
            this.MakeAnAppointmentButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.MakeAnAppointmentButton.BackColor = System.Drawing.Color.CornflowerBlue;
            this.MakeAnAppointmentButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.MakeAnAppointmentButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MakeAnAppointmentButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MakeAnAppointmentButton.ForeColor = System.Drawing.Color.White;
            this.MakeAnAppointmentButton.Location = new System.Drawing.Point(387, 397);
            this.MakeAnAppointmentButton.Name = "MakeAnAppointmentButton";
            this.MakeAnAppointmentButton.Size = new System.Drawing.Size(107, 30);
            this.MakeAnAppointmentButton.TabIndex = 6;
            this.MakeAnAppointmentButton.TabStop = false;
            this.MakeAnAppointmentButton.Text = "Записаться";
            this.MakeAnAppointmentButton.UseVisualStyleBackColor = false;
            this.MakeAnAppointmentButton.Click += new System.EventHandler(this.MakeAnAppointmentButton_Click);
            // 
            // SignInAsDoctorButton
            // 
            this.SignInAsDoctorButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SignInAsDoctorButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SignInAsDoctorButton.FlatAppearance.BorderSize = 0;
            this.SignInAsDoctorButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(239)))), ((int)(((byte)(253)))));
            this.SignInAsDoctorButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(239)))), ((int)(((byte)(253)))));
            this.SignInAsDoctorButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SignInAsDoctorButton.ImageIndex = 0;
            this.SignInAsDoctorButton.ImageList = this.ImageListForButton;
            this.SignInAsDoctorButton.Location = new System.Drawing.Point(806, 19);
            this.SignInAsDoctorButton.Name = "SignInAsDoctorButton";
            this.SignInAsDoctorButton.Size = new System.Drawing.Size(48, 48);
            this.SignInAsDoctorButton.TabIndex = 7;
            this.SignInAsDoctorButton.TabStop = false;
            this.SignInAsDoctorButton.UseVisualStyleBackColor = true;
            this.SignInAsDoctorButton.Click += new System.EventHandler(this.SignInAsDoctorButton_Click);
            this.SignInAsDoctorButton.MouseLeave += new System.EventHandler(this.SignInAsDoctorButton_MouseLeave);
            this.SignInAsDoctorButton.MouseHover += new System.EventHandler(this.SignInAsDoctorButton_MouseHover);
            // 
            // ImageListForButton
            // 
            this.ImageListForButton.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.ImageListForButton.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageListForButton.ImageStream")));
            this.ImageListForButton.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageListForButton.Images.SetKeyName(0, "six-pointed-star.png");
            this.ImageListForButton.Images.SetKeyName(1, "six-pointed-star-filled.png");
            // 
            // EmptyTextFieldLabel1
            // 
            this.EmptyTextFieldLabel1.AutoSize = true;
            this.EmptyTextFieldLabel1.ForeColor = System.Drawing.Color.Red;
            this.EmptyTextFieldLabel1.Location = new System.Drawing.Point(406, 103);
            this.EmptyTextFieldLabel1.Name = "EmptyTextFieldLabel1";
            this.EmptyTextFieldLabel1.Size = new System.Drawing.Size(234, 20);
            this.EmptyTextFieldLabel1.TabIndex = 8;
            this.EmptyTextFieldLabel1.Text = "Это поле не может быть пустым";
            this.EmptyTextFieldLabel1.Visible = false;
            // 
            // EmptyTextFieldLabel2
            // 
            this.EmptyTextFieldLabel2.AutoSize = true;
            this.EmptyTextFieldLabel2.ForeColor = System.Drawing.Color.Red;
            this.EmptyTextFieldLabel2.Location = new System.Drawing.Point(406, 175);
            this.EmptyTextFieldLabel2.Name = "EmptyTextFieldLabel2";
            this.EmptyTextFieldLabel2.Size = new System.Drawing.Size(231, 20);
            this.EmptyTextFieldLabel2.TabIndex = 9;
            this.EmptyTextFieldLabel2.Text = "Неправильный формат номера";
            this.EmptyTextFieldLabel2.Visible = false;
            // 
            // EmptyTextFieldLabel3
            // 
            this.EmptyTextFieldLabel3.AutoSize = true;
            this.EmptyTextFieldLabel3.ForeColor = System.Drawing.Color.Red;
            this.EmptyTextFieldLabel3.Location = new System.Drawing.Point(406, 281);
            this.EmptyTextFieldLabel3.Name = "EmptyTextFieldLabel3";
            this.EmptyTextFieldLabel3.Size = new System.Drawing.Size(234, 20);
            this.EmptyTextFieldLabel3.TabIndex = 10;
            this.EmptyTextFieldLabel3.Text = "Это поле не может быть пустым";
            this.EmptyTextFieldLabel3.Visible = false;
            // 
            // AppoitmentLabel
            // 
            this.AppoitmentLabel.AutoSize = true;
            this.AppoitmentLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AppoitmentLabel.Location = new System.Drawing.Point(43, 26);
            this.AppoitmentLabel.Name = "AppoitmentLabel";
            this.AppoitmentLabel.Size = new System.Drawing.Size(497, 28);
            this.AppoitmentLabel.TabIndex = 11;
            this.AppoitmentLabel.Text = "Чтобы записаться на прием, заполните форму ниже:";
            // 
            // AppointmentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(239)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(878, 465);
            this.Controls.Add(this.AppoitmentLabel);
            this.Controls.Add(this.EmptyTextFieldLabel3);
            this.Controls.Add(this.EmptyTextFieldLabel2);
            this.Controls.Add(this.EmptyTextFieldLabel1);
            this.Controls.Add(this.SignInAsDoctorButton);
            this.Controls.Add(this.MakeAnAppointmentButton);
            this.Controls.Add(this.ComplaintTextBox);
            this.Controls.Add(this.PhoneNumberTextBox);
            this.Controls.Add(this.FullNameTextBox);
            this.Controls.Add(this.ComplaintLabel);
            this.Controls.Add(this.PhoneNumberLabel);
            this.Controls.Add(this.FullNameLabel);
            this.Name = "AppointmentForm";
            this.Text = "Запись на прием";
            this.Load += new System.EventHandler(this.AppointmentForm_Load);
            this.Resize += new System.EventHandler(this.AppointmentForm_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FullNameLabel;
        private System.Windows.Forms.Label PhoneNumberLabel;
        private System.Windows.Forms.Label ComplaintLabel;
        private System.Windows.Forms.TextBox FullNameTextBox;
        private System.Windows.Forms.TextBox PhoneNumberTextBox;
        private System.Windows.Forms.TextBox ComplaintTextBox;
        private System.Windows.Forms.Button MakeAnAppointmentButton;
        private System.Windows.Forms.Button SignInAsDoctorButton;
        private System.Windows.Forms.Label EmptyTextFieldLabel1;
        private System.Windows.Forms.Label EmptyTextFieldLabel2;
        private System.Windows.Forms.Label EmptyTextFieldLabel3;
        private System.Windows.Forms.ImageList ImageListForButton;
        private System.Windows.Forms.Label AppoitmentLabel;
    }
}

