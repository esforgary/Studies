﻿
namespace Kursach
{
    partial class SignInAsDoctorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SignUpAsDoctorLabel = new System.Windows.Forms.Label();
            this.DoctorPasswordLabel = new System.Windows.Forms.Label();
            this.DoctorPasswordTextBox = new System.Windows.Forms.TextBox();
            this.SignInButton = new System.Windows.Forms.Button();
            this.EmptyTextFieldLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SignUpAsDoctorLabel
            // 
            this.SignUpAsDoctorLabel.AutoSize = true;
            this.SignUpAsDoctorLabel.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SignUpAsDoctorLabel.Location = new System.Drawing.Point(60, 30);
            this.SignUpAsDoctorLabel.Name = "SignUpAsDoctorLabel";
            this.SignUpAsDoctorLabel.Size = new System.Drawing.Size(681, 81);
            this.SignUpAsDoctorLabel.TabIndex = 0;
            this.SignUpAsDoctorLabel.Text = "Хотите войти как врач?";
            // 
            // DoctorPasswordLabel
            // 
            this.DoctorPasswordLabel.AutoSize = true;
            this.DoctorPasswordLabel.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DoctorPasswordLabel.Location = new System.Drawing.Point(101, 166);
            this.DoctorPasswordLabel.Name = "DoctorPasswordLabel";
            this.DoctorPasswordLabel.Size = new System.Drawing.Size(190, 37);
            this.DoctorPasswordLabel.TabIndex = 1;
            this.DoctorPasswordLabel.Text = "Пароль врача";
            // 
            // DoctorPasswordTextBox
            // 
            this.DoctorPasswordTextBox.Location = new System.Drawing.Point(101, 206);
            this.DoctorPasswordTextBox.Name = "DoctorPasswordTextBox";
            this.DoctorPasswordTextBox.Size = new System.Drawing.Size(590, 27);
            this.DoctorPasswordTextBox.TabIndex = 2;
            this.DoctorPasswordTextBox.TextChanged += new System.EventHandler(this.DoctorPasswordTextBox_TextChanged);
            // 
            // SignInButton
            // 
            this.SignInButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.SignInButton.BackColor = System.Drawing.Color.CornflowerBlue;
            this.SignInButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SignInButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SignInButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SignInButton.ForeColor = System.Drawing.Color.White;
            this.SignInButton.Location = new System.Drawing.Point(348, 311);
            this.SignInButton.Name = "SignInButton";
            this.SignInButton.Size = new System.Drawing.Size(94, 29);
            this.SignInButton.TabIndex = 3;
            this.SignInButton.TabStop = false;
            this.SignInButton.Text = "Войти";
            this.SignInButton.UseVisualStyleBackColor = false;
            this.SignInButton.Click += new System.EventHandler(this.SignInButton_Click);
            // 
            // EmptyTextFieldLabel
            // 
            this.EmptyTextFieldLabel.AutoSize = true;
            this.EmptyTextFieldLabel.ForeColor = System.Drawing.Color.Red;
            this.EmptyTextFieldLabel.Location = new System.Drawing.Point(101, 236);
            this.EmptyTextFieldLabel.Name = "EmptyTextFieldLabel";
            this.EmptyTextFieldLabel.Size = new System.Drawing.Size(234, 20);
            this.EmptyTextFieldLabel.TabIndex = 4;
            this.EmptyTextFieldLabel.Text = "Это поле не может быть пустым";
            this.EmptyTextFieldLabel.Visible = false;
            // 
            // SignInAsDoctorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(239)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(800, 393);
            this.Controls.Add(this.EmptyTextFieldLabel);
            this.Controls.Add(this.SignInButton);
            this.Controls.Add(this.DoctorPasswordTextBox);
            this.Controls.Add(this.DoctorPasswordLabel);
            this.Controls.Add(this.SignUpAsDoctorLabel);
            this.Name = "SignInAsDoctorForm";
            this.Text = "Войти как врач";
            this.Load += new System.EventHandler(this.SignUpAsDoctorForm_Load);
            this.Resize += new System.EventHandler(this.SignUpAsDoctorForm_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SignUpAsDoctorLabel;
        private System.Windows.Forms.Label DoctorPasswordLabel;
        private System.Windows.Forms.TextBox DoctorPasswordTextBox;
        private System.Windows.Forms.Button SignInButton;
        private System.Windows.Forms.Label EmptyTextFieldLabel;
    }
}