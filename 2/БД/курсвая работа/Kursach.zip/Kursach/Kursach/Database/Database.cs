﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Text.RegularExpressions;

namespace DatabaseCore
{
    public class Database
    {
        private string connetionString; //Строка, содержащая данные для подключения к БД
        private SqlConnection con; //Переменная подключения к БД
        private SqlCommand sc = new SqlCommand(); //Переменная, содержащая команды (query) БД

        public Database(string connetionString) //Конструктор БД
        {
            this.connetionString = connetionString;
            con = new SqlConnection(connetionString);
            sc.Connection = con;
        }

        public void InsertNewPatient(string name_patient, string phone) //Добавить в БД нового пациента
        {
            try
            {
                con.Open();
                sc.CommandText = "SELECT COUNT(*) " +
                    "FROM Patient " +
                    "WHERE Name_Patient='" + name_patient + "' " +
                    "AND Phone='" + phone + "'";
                int patientCount = (int)sc.ExecuteScalar(); //Проверка, есть ли уже человек с такими ФИО и телефоном в таблице
                if (patientCount == 0) //Если такого человека нет, добавляем его в таблицу
                {
                    sc.CommandText = "INSERT INTO Patient " +
                        "VALUES (" + "'" + name_patient + "'" + ", " + "'" + phone + "'" + ")";
                    sc.ExecuteNonQuery();
                }
                con.Close();
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        private int FindPossibleDisease(Dictionary<int, string> diseases, string symptoms, string complaint) //Выбор самой вероятной болезни по имеющимся симптомам
        {
           
            List<string> keyWords = new List<string>(Regex.Split(symptoms, @"[/\s;]+")); 
            keyWords.RemoveAll(keyWord => keyWord.Length <= 2);
            for (int i = 0; i < keyWords.Count; i++) 
                keyWords[i] = keyWords[i].Substring(0, 3); 
            int max = 0;
            int maxId = 0;
            foreach (int id in diseases.Keys)
            {
                int evaluation = 0;
                foreach (string keyWord in keyWords)
                    if (complaint.ToLower().Contains(keyWord) && diseases[id].Contains(keyWord))
                        evaluation += 1;
                if (evaluation > max)
                {
                    max = evaluation;
                    maxId = id;
                }
            }
            return maxId;
        }

        public int Diagnose(string complaint) //Определение болезни
        {
            try
            {
                con.Open();
                Dictionary<int, string> diseases = new Dictionary<int, string>();
                string symptoms = "";
                sc.CommandText = "SELECT ID_Dis, Symptom FROM Disease";
                SqlDataReader sqlreader = sc.ExecuteReader();
                while (sqlreader.Read())
                {
                    diseases[sqlreader.GetInt32(sqlreader.GetOrdinal("ID_Dis"))] = sqlreader.GetString(sqlreader.GetOrdinal("Symptom"));
                    symptoms += sqlreader.GetString(sqlreader.GetOrdinal("Symptom")) + ";";
                }
                sqlreader.Close();
                int id_dis = FindPossibleDisease(diseases, symptoms, complaint);
                con.Close();
                return id_dis;
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        public int InsertNewInspection(int id_dis, string complaint, string name_patient, string phone) //Добавить в БД новый осмотр
        {
            DateTime datetime = DateTime.Now;
            try
            {
                con.Open();
                sc.CommandText = "INSERT INTO Inspection (ID_Patient, ID_Dis, Date, Complain) " +
                    "SELECT ID_Patient, " + id_dis + " AS ID_Dis, '" + datetime.ToString("yyyy-MM-dd HH:mm:ss.fff") + "' AS Date, '" + complaint + "' AS Complain " +
                    "FROM Patient " +
                    "WHERE Name_Patient='" + name_patient + "' " +
                    "AND Phone='" + phone + "' " +
                    "SELECT @@IDENTITY AS 'Identity'";
                int id_ins = Convert.ToInt32(sc.ExecuteScalar());
                con.Close();
                return id_ins;
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        public List<Inspection> GetAllInspections() //Получить список всех осмотров
        {
            List<Inspection> inspections = new List<Inspection>();
            try
            {
                con.Open();
                sc.CommandText = "SELECT Inspection.ID_Ins, Patient.Name_Patient, Disease.Name_Dis, FORMAT(Inspection.Date, N'dd.MM.yyyy') AS Date, Inspection.Complain " +
                    "FROM Inspection " +
                    "JOIN Patient ON(Inspection.ID_Patient = Patient.ID_Patient) " +
                    "JOIN Disease On(Inspection.ID_Dis = Disease.ID_Dis)";
                SqlDataReader sqlreader = sc.ExecuteReader();
                while (sqlreader.Read())
                {
                    inspections.Add(new Inspection(sqlreader.GetInt32(sqlreader.GetOrdinal("ID_Ins")),
                        sqlreader.GetString(sqlreader.GetOrdinal("Name_Patient")),
                        sqlreader.GetString(sqlreader.GetOrdinal("Name_Dis")),
                        sqlreader.GetString(sqlreader.GetOrdinal("Date")).ToString(),
                        sqlreader.GetString(sqlreader.GetOrdinal("Complain"))));
                }
                sqlreader.Close();
                con.Close();
                return inspections;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public string GetDisease(int id_ins) //Получить болезнь из определённого осмотра
        {
            try
            {
                con.Open();
                sc.CommandText = "SELECT Disease.Name_Dis " +
                    "FROM Disease " +
                    "JOIN Inspection ON (Inspection.ID_Dis = Disease.ID_Dis) " +
                    "WHERE Inspection.ID_Ins = " + id_ins;
                SqlDataReader sqlreader = sc.ExecuteReader();
                sqlreader.Read();
                string disease = sqlreader.GetString(sqlreader.GetOrdinal("Name_Dis"));
                sqlreader.Close();
                con.Close();
                return disease;
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        public Dictionary<string, int> GetCountedDiseases() //Получить количество заражений каждой болезнью
        {
            Dictionary<string, int> countedDiseases = new Dictionary<string, int>();
            try
            {
                con.Open();
                sc.CommandText = "SELECT Disease.Name_Dis, COUNT(Disease.Name_Dis) AS Count " +
                    "FROM Inspection " +
                    "JOIN Disease ON(Inspection.ID_Dis = Disease.ID_Dis) " +
                    "GROUP BY Disease.Name_Dis " +
                    "ORDER BY Count DESC";
                SqlDataReader sqlreader = sc.ExecuteReader();
                while (sqlreader.Read())
                {
                    countedDiseases[sqlreader.GetString(sqlreader.GetOrdinal("Name_Dis"))] = sqlreader.GetInt32(sqlreader.GetOrdinal("Count"));
                }
                sqlreader.Close();
                con.Close();
                return countedDiseases;
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        public Dictionary<string, int> GetCountedPatients() //Получить количество осмотров каждого пациента
        {
            Dictionary<string, int> countedPatients = new Dictionary<string, int>();
            try
            {
                con.Open();
                sc.CommandText = "SELECT Patient.Name_Patient, COUNT(Patient.Name_Patient) AS Count " +
                    "FROM Inspection " +
                    "JOIN Patient ON(Inspection.ID_Patient = Patient.ID_Patient) " +
                    "GROUP BY Patient.Name_Patient " +
                    "ORDER BY Count DESC";
                SqlDataReader sqlreader = sc.ExecuteReader();
                while (sqlreader.Read())
                {
                    countedPatients[sqlreader.GetString(sqlreader.GetOrdinal("Name_Patient"))] = sqlreader.GetInt32(sqlreader.GetOrdinal("Count"));
                }
                sqlreader.Close();
                con.Close();
                return countedPatients;
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        public Dictionary<string, int> GetCountedMedication() //Получить количество попаданий каждого препарата в рецепт
        {
            Dictionary<string, int> countedMedication = new Dictionary<string, int>();
            try
            {
                con.Open();
                sc.CommandText = "SELECT Medication.Name_Med, COUNT(Medication.Name_Med) AS Count " +
                    "FROM Recept " +
                    "JOIN Medication ON(Recept.ID_Med = Medication.ID_Med) " +
                    "GROUP BY Medication.Name_Med " +
                    "ORDER BY Count DESC";
                SqlDataReader sqlreader = sc.ExecuteReader();
                while (sqlreader.Read())
                {
                    countedMedication[sqlreader.GetString(sqlreader.GetOrdinal("Name_Med"))] = sqlreader.GetInt32(sqlreader.GetOrdinal("Count"));
                }
                sqlreader.Close();
                con.Close();
                return countedMedication;
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        public void InsertNewRecept(int id_ins) //Добавить в БД новый рецепт
        {
            Random random = new Random();
            try
            {
                con.Open();
                sc.CommandText = "INSERT INTO Recept " +
                    "SELECT Inspection.ID_Ins, " +
                    "Treatment.ID_Med, " +
                    "IIF(Disease.Complexity=1, ABS(CHECKSUM(NewId())) % 4 + 1, IIF(Disease.Complexity=2, ABS(CHECKSUM(NewId())) % 2 + 3, 4)) AS Count_receptions, " +
                    "IIF(Disease.Complexity=1, ABS(CHECKSUM(NewId())) % 15 + 7, ABS(CHECKSUM(NewId())) % 8 + 14) AS Count_days, " +
                    "Disease.Complexity " +
                    "FROM Disease " +
                    "JOIN Inspection ON (Inspection.ID_Dis = Disease.ID_Dis) " +
                    "JOIN Treatment ON (Disease.ID_Dis = Treatment.ID_Dis) " +
                    "WHERE Inspection.ID_Ins = " + id_ins;
                sc.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }

        public List<Recept> GetRecept(int id_ins) //Получить рецепт
        {
            List<Recept> recept = new List<Recept>();
            try
            {
                con.Open();
                sc.CommandText = "SELECT Medication.Name_Med, Recept.Dosage, Recept.Count_receptions, Recept.Count_days " +
                    "FROM Recept " +
                    "JOIN Medication ON (Recept.ID_Med = Medication.ID_Med) " +
                    "WHERE Recept.ID_Ins = " + id_ins;
                SqlDataReader sqlreader = sc.ExecuteReader();
                while (sqlreader.Read())
                {
                    recept.Add(new Recept(
                    sqlreader.GetString(sqlreader.GetOrdinal("Name_Med")),
                    sqlreader.GetInt32(sqlreader.GetOrdinal("Dosage")),
                    sqlreader.GetInt32(sqlreader.GetOrdinal("Count_receptions")),
                    sqlreader.GetInt32(sqlreader.GetOrdinal("Count_days"))
                    ));
                }
                sqlreader.Close();
                con.Close();
                return recept;
            }
            catch (Exception)
            {
                throw new Exception("Не могу подключиться к базе данных!");
            }
        }
    }

    public class Inspection //Класс осмотра
    {
        public int ID_Ins { get; private set; }
        public string Name_Patient { get; private set; }
        public string Name_Dis { get; private set; }
        public string Date { get; private set; }
        public string Complain { get; private set; }

        public Inspection(int id_ins, string name_patient, string name_dis, string date, string complain)
        {
            ID_Ins = id_ins;
            Name_Patient = name_patient;
            Name_Dis = name_dis;
            Date = date;
            Complain = complain;
        }
    }

    public class Recept //Класс рецепта
    {
        public string Name_Med { get; private set; }
        public int Dosage { get; private set; }
        public int Count_receptions { get; private set; }
        public int Count_days { get; private set; }

        public Recept(string name_Med, int dosage, int count_receptions, int count_days)
        {
            Name_Med = name_Med;
            Dosage = dosage;
            Count_receptions = count_receptions;
            Count_days = count_days;
        }
    }
}
