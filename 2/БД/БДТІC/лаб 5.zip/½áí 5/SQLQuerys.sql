/*1*/
insert into Tovar (ID_Tovar, NameTovar, Sort , ID_Maker)
Values (14, '���������� ������','������',3)

/*2*/
insert into Client (ID_Client, NameClient, ID_CityClient)
values (6, '�� ���� ����', 5)

/*3*/
insert into Tovar (ID_Tovar, NameTovar, Sort, Price, ID_Maker)
select max(ID_Tovar)+1, '���������� �������� ��� 18+', '��������', 13499, 2
from Tovar

/*4*/
insert into TovarSortFirst (ID_Tovar, NameTovar,Price,Material)
select ID_Tovar, NameTovar, Price, Material
from Tovar
where Sort = '1'

/*5.1*/
insert into TovarSortBest (NameTovar,Price,Material)
select  NameTovar, Price, Material
from Tovar

/*5.2*/
insert into TovarSortBest (NameTovar,Price,Material)
select  NameTovar, Price, Material
from Tovar
where Sort = '������' and Price >= 650

/*5.3*/
insert into TovarSortBest (NameTovar,Price,Material)
select  NameTovar, Price, Material
from Tovar
where Sort = '������' and Price between 450 and 650

/*5.4*/
set identity_insert TovarSortBest on
insert into TovarSortBest (ID_Tovar, NameTovar, Price, Material)
select ID_Tovar, NameTovar, Price, Material 
from Tovar
where Sort = '������' 

/*6*/
insert into ReportTovar2006_2007(ID_Tovar)
select ID_Tovar
from Tovar

/*7*/
insert into Sklad (ID_Tovar) 
select ID_Tovar 
from Tovar 
where ID_Tovar NOT IN(select ID_Tovar from Sklad)

/*8*/
Update Tovar set Sort = '1'
where ID_Tovar = 14

/*9*/
Update Tovar set Price = price*0.8
where sort = '������'

/*10*/
Update Tovar set Price = price*2

/*11*/
Update Tovar set Price = price*0.9
where price = (select MAX(Price) from Tovar )

/*12*/
Update Tovar set Price = price*0.5 , Sort = '2'
where ID_Tovar = 5

/*13*/
Update Tovar set Price = price*0.5
from Tovar inner join Sklad on Tovar.ID_Tovar = Sklad.ID_Tovar
where Stock < 10

/*14*/
Update Tovar set AVG_Sdelka = (select sum(Quantity)/count(Sale.ID_Tovar) 
							   from Sale inner join Tovar as T1 on Sale.ID_Tovar = T1.ID_Tovar 
							   where Tovar.ID_Tovar = T1.ID_Tovar)
from Tovar

/*15.1*/
select SUM(Quantity) as Tov_2006
from Sale
where YEAR(Data)='2006'
group by ID_Tovar;

/*15.2*/
UPDATE ReportTovar2006_2007 set SUM_Tovar2006 = 
                (select SUM(Quantity) 
                from SALE 
                where ReportTovar2006_2007.ID_Tovar = Sale.ID_Tovar and YEAR(Data) = 2006), 
                SUM_Tovar2007 = (select SUM(Quantity) 
                from SALE 
                where ReportTovar2006_2007.ID_Tovar = Sale.ID_Tovar and YEAR(Data) = 2007);


/*15.3*/
Update ReportTovar2006_2007 set SUM_Tovar2006 = (select sum(Quantity) 
                                                 from Tovar inner join Sale on Tovar.ID_Tovar = Sale.ID_Tovar 
												 where T1.ID_Tovar = Sale.ID_Tovar and YEAR(Data) = 2006),
SUM_Tovar2007 = (Select sum(Quantity) 
                 from Tovar inner join Sale on Tovar.ID_Tovar = Sale.ID_Tovar 
				 where T1.ID_Tovar = Tovar.ID_Tovar and YEAR(Data) = 2007),
Minus = SUM_Tovar2006 - SUM_Tovar2007
from Tovar as T1 inner join ReportTovar2006_2007 on T1.ID_Tovar = ReportTovar2006_2007.ID_Tovar

/*16*/
delete from ReportTovar2006_2007

/*17*/
delete from Tovar
where ID_Tovar = 9 

/*18*/
select Tovar.ID_Tovar , NameTovar
from Tovar inner join Sale on Sale.ID_Tovar= Tovar.ID_Tovar
where Data = (select MAx(Data) from Sale)

/*19*/
select Tovar.ID_Tovar, NameTovar, Client.ID_Client, NameClient, (select sum(Quantity) 
																 from Sale as S1 
																 where Tovar.ID_Tovar = S1.ID_Tovar and S1.ID_Client = Sale.ID_Client and YEAR(Data) = 2006 
																 having Sum(Quantity) >=2 )
from Client inner join Sale on Client.ID_Client = Sale.ID_Client inner join Tovar on Tovar.ID_Tovar = Sale.ID_Tovar
order by 5 DESC

/*20*/
select left(NameClient, 3) ,sum(Quantity*Price) as Income
from Client inner join Sale on Client.ID_Client = Sale.ID_Client inner join Tovar on Tovar.ID_Tovar = Sale.ID_Tovar
group by left(NameClient, 3)

/*21*/
select NameMaker
from Maker inner join (Sale inner join Tovar on Sale.ID_Tovar=Tovar.ID_Tovar) on Maker.ID_Maker=Tovar.ID_Maker
group by NameMaker
having count(NameMaker) >= all (select count(ID_Maker) from Sale inner join Tovar on Sale.ID_Tovar=Tovar.ID_Tovar group by ID_Maker)

/*22*/
select distinct ID_Maker
from Tovar
where NOT EXISTS (select Sale.ID_Tovar from Sale
where Tovar.ID_Tovar = Sale.ID_Tovar);

/*23*/
select *
from Tovar
order by (select Stock from Sklad where Tovar.ID_Tovar = Sklad.ID_Tovar) DESC;

/*24*/
select Tovar.*
from Tovar INNER JOIN (select ID_Maker, COUNT(*) as P
from Sale INNER JOIN Tovar on Sale.ID_Tovar = Tovar.ID_Tovar 
group by ID_Maker) as S on Tovar.ID_Maker = S.ID_Maker
order by P DESC;

/*25*/
select distinct T1.ID_Tovar, NameTovar, (select SUM(Price * Quantity) 
										 from Tovar T2 INNER JOIN Sale S2 on T2.ID_Tovar = S2.ID_Tovar 
										 where Year(Data) = 2007 and T2.ID_Tovar = T1.ID_Tovar) as DOXOD2007, (select SUM(Price * Quantity) 
																											   from Tovar T3 INNER JOIN Sale S3 on T3.ID_Tovar = S3.ID_Tovar 
																											   where T3.ID_Tovar = T1.ID_Tovar) as DOXOD
from Tovar T1 INNER JOIN Sale S1 on T1.ID_Tovar = S1.ID_Tovar;

/*26*/
select distinct T1.ID_Tovar, NameTovar, (select SUM(Price * Quantity) 
										 from Tovar T2 INNER JOIN Sale S2 on T2.ID_Tovar = S2.ID_Tovar 
										 where Year(Data) = 2007 and T2.ID_Tovar = T1.ID_Tovar) as "DOXOD2007"
from Tovar T1 INNER JOIN Sale S1 on T1.ID_Tovar = S1.ID_Tovar
where (select SUM(Quantity) 
       from Sale S2 
	   where YEAR(Data) = 2007  and S2.ID_Tovar = S1.ID_Tovar) BETWEEN 3 AND 20;
