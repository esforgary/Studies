/*1.1*/
select min(Price) as MinPrice 
from Tovar;

/*1.2*/
select top 1 Price as MinPrice 
from Tovar 
order by Price;

/*2*/
select distinct top 3 Data 
from Sale 
order by Data;

/*3*/
select * 
from Sale 
where Data in(select distinct top 3 Data 
			  from Sale 
			  order by Data)

/*4.1*/
select * 
from Client 
where ID_Client <> all(select ID_Client 
					   from Sale)

/*4.2*/
select * 
from Client c 
where not exists (select * 
                  from Sale s 
				  where s.ID_Client=c.ID_Client)

/*5.1*/
select distinct NameTovar, Price 
from Tovar 
where ID_Tovar = any(select ID_Tovar 
                     from Sale)

/*5.2*/
select distinct NameTovar, Price 
from Tovar t 
where exists (select* 
              from Sale s 
			  where s.ID_Tovar=t.ID_Tovar)

/*6.1*/
select c1.ID_Client, NameClient
from Client c1, Tovar t1, Sale s1 
where t1.ID_Tovar=s1.ID_Tovar and s1.ID_Client=c1.ID_Client 
group by c1.ID_Client, NameClient
having sum(Price*Quantity) >=all (select sum(Price*Quantity) 
                                  from Client c2, Tovar t2, Sale s2 
							      where t2.ID_Tovar=s2.ID_Tovar and s2.ID_Client=c2.ID_Client 
							      group by c2.ID_Client, NameClient)

/*6.2*/
select c.ID_Client, NameClient
from Client c, Sale s, Tovar t
where c.ID_Client=s.ID_Client and s.ID_Tovar=t.ID_Tovar
group by c.ID_Client, NameClient
having sum(Quantity*Price)=(select max(T.zapr) 
                            from(select sum(Quantity*Price) as zapr from Sale s, Tovar t
                                 where s.ID_Tovar=t.ID_Tovar
								 group by s.ID_Client) as T );

/*6.3*/
select c1.ID_Client, NameClient
from Client c1, Tovar t1, Sale s1 
where t1.ID_Tovar=s1.ID_Tovar and s1.ID_Client=c1.ID_Client 
group by c1.ID_Client, NameClient
having sum(Price*Quantity) = (select top 1 sum(Price*Quantity) 
                              from Client c2, Tovar t2, Sale s2 
							  where t2.ID_Tovar=s2.ID_Tovar and s2.ID_Client=c2.ID_Client 
							  group by c2.ID_Client, NameClient
							  order by sum(Price*Quantity) desc)

/*7.1*/
select 'ID_CityMaker' as StatusCity, CityName as CityName 
from Maker m inner join City c on m.ID_CityMaker=c.ID_City
union 
select 'ID_CityClient', CityName 
from Client cl inner join City c on cl.ID_CityClient=c.ID_City
order by 2;

/*7.2*/
select 'ID_CityMaker' as StatusCity, ID_CityMaker as ID_City 
from Maker
union 
select 'ID_CityClient', ID_CityClient 
from Client
order by 2;

/*8.1*/
select distinct ID_City 
from City c inner join Client cl on c.ID_City=cl.ID_CityClient inner join Maker m on c.ID_City=m.ID_CityMaker 
order by ID_City;

/*8.2*/
select distinct ID_CityMaker as ID_City
from Maker m 
where ID_CityMaker = any(select ID_CityClient 
                         from Client)

/*8.3*/
select distinct ID_CityMaker 
from Maker m 
where ID_CityMaker in(select ID_CityClient 
                      from Client)

/*8.4*/
select distinct ID_CityMaker 
from Maker m 
where exists (select ID_CityClient 
              from Client cl 
			  where cl.ID_CityClient=m.ID_CityMaker)

/*8.5*/
select ID_CityMaker as ID_City 
from Maker
intersect
select ID_CityClient 
from Client
order by 1

/*9.1*/
select distinct ID_CityClient 
from Client cl left join Maker m on cl.ID_CityClient=m.ID_CityMaker 
where NameMaker is null

/*9.2*/
select distinct ID_CityClient 
from Client 
where ID_CityClient <>all(select ID_CityMaker 
                          from Maker)

/*9.3*/
select distinct ID_CityClient 
from Client 
where ID_CityClient not in(select ID_CityMaker 
                           from Maker)

/*9.4*/
select distinct ID_CityClient 
from Client cl 
where not exists(select * 
                 from Maker m 
				 where m.ID_CityMaker=cl.ID_CityClient)

/*9.5*/
select ID_CityClient 
from Client
except
select ID_CityMaker 
from Maker

/*10*/
select Sort, NameTovar 
from Tovar T1 
where Price = (select top 1 Price 
               from Tovar T2 
			   where T2.Sort=T1.Sort 
			   order by Price desc)

/*11*/
select distinct NameMaker, NameTovar, Price 
from Maker m1 inner join Tovar t1 on t1.ID_Maker=m1.ID_Maker 
where Price = (select min(Price) 
               from Tovar t2
               where t2.ID_Maker=t1.ID_Maker)

/*12*/
select s1.Data, max(Quantity*Price) as Max_price 
from Tovar t1 inner join Sale s1 on s1.ID_Tovar=t1.ID_Tovar
group by s1.Data
having max(Quantity*Price)=(select max(Quantity*Price) 
                            from Tovar t2 inner join Sale s2 on s2.ID_Tovar=t2.ID_Tovar
							where s1.Data=s2.Data)

/*13.1*/
select t.ID_Tovar, max(t.NameTovar), sum(Quantity*Price) as Price 
from Tovar t left join Sale s on s.ID_Tovar=t.ID_Tovar
group by t.ID_Tovar;

/*13.2*/
select t2.ID_Tovar,max(NameTovar),(select sum(Quantity*Price) 
                                   from Tovar as t1 INNER JOIN Sale as s1 on s1.ID_Tovar=t1.ID_Tovar 
								   where t1.ID_Tovar=t2.ID_Tovar)
from Tovar as t2 LEFT JOIN Sale as s2 on s2.ID_Tovar=t2.ID_Tovar
group by t2.ID_Tovar

/*14*/
select s.ID_Tovar, max(NameTovar) as NameTovar, (select sum(Quantity*Price)
                                    from Sale s1, Tovar t1 
							        where s1.ID_Tovar=t1.ID_Tovar and s.ID_Tovar=s1.ID_Tovar) as Sum, 
                              (select sum(Quantity*Price)
                               from Sale s1, Tovar t1 
							   where s1.ID_Tovar=t1.ID_Tovar and s.ID_Tovar=s1.ID_Tovar and year(Data)=2006) as Sum2006
from Sale s, Tovar t 
where s.ID_Tovar=t.ID_Tovar
group by s.ID_Tovar;

/*15*/
select distinct s.ID_Tovar, ID_Client, 
					(select sum(Quantity)
				     from Sale s1
					 where s1.ID_Tovar=s.ID_Tovar
					 group by s1.ID_Tovar) as SumTovar,

				(select sum(Quantity) 
				from Sale s2
				where s2.ID_Client=s.ID_Client
				group by s2.ID_Client) as SumClient,

		(select sum(Quantity) 
		from Sale s3
		where s.ID_Client=s3.ID_Client and s.ID_Tovar=s3.ID_Tovar
		group by s3.ID_Client, s3.ID_Tovar) as SumTovarClient

from Sale s
